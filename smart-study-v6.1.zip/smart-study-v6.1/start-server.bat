@echo off
title Smart Study Schedule - Local Server
color 0A
cd /d "%~dp0"

set BIND=127.0.0.1
if "%1"=="--lan" set BIND=0.0.0.0

echo ============================================
echo   Smart Study Schedule v6.1 - Local Server
echo ============================================
echo.

where python >nul 2>nul
if %errorlevel%==0 (
    set PYCMD=python
    goto :found
)
where python3 >nul 2>nul
if %errorlevel%==0 (
    set PYCMD=python3
    goto :found
)
where py >nul 2>nul
if %errorlevel%==0 (
    set PYCMD=py
    goto :found
)

echo [!] Python not found on your machine.
echo.
echo     To run the app as a full installable PWA, install Python (free):
echo       1) Go to https://www.python.org/downloads/
echo       2) Download and install the latest version
echo          (make sure to tick "Add to PATH" during installation)
echo       3) Run this file again after installing.
echo.
echo     You can also open index.html directly by double-clicking it
echo     for basic use (PWA and offline features need the local server).
echo.
pause
exit /b 1

:found
set PORT=8000
powershell -NoProfile -Command "try{(New-Object Net.Sockets.TcpClient).Connect('127.0.0.1',%PORT%);exit 0}catch{exit 1}" >nul 2>nul
if %errorlevel%==0 (
    echo [!] Port %PORT% is already in use ^(likely from a previous run^).
    echo     Switching to port 8001 instead.
    set PORT=8001
    echo.
)

set LAN_IP=
if "%BIND%"=="0.0.0.0" (
    for /f "delims=" %%A in ('powershell -NoProfile -Command "(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*' } | Select-Object -First 1 -ExpandProperty IPAddress)"') do set LAN_IP=%%A
)

echo Starting the local server on port %PORT% ...
echo.
echo ============================================
echo   On this computer, the browser will open at:
echo   http://localhost:%PORT%
echo.
if not "%LAN_IP%"=="" (
echo   --lan mode: open this from any device on the same Wi-Fi
echo   ^(e.g. your Android phone, with no extra app^):
echo   http://%LAN_IP%:%PORT%
echo.
)
echo   [!] If a blank page appears, just wait one moment
echo       then press F5 to refresh - it will work instantly.
echo.
echo   To install the app: click the install icon in the
echo   Chrome/Edge address bar, or use Settings inside the app.
echo.
echo   Note: to reach the app from other devices on your
echo   network, run:  start-server.bat --lan
echo   (click "Allow" if Windows Firewall asks for permission)
echo.
echo   To stop the server: close this window or press Ctrl+C.
echo ============================================
echo.

start "" /min powershell -NoProfile -WindowStyle Hidden -Command "for($i=0;$i -lt 40;$i++){try{(New-Object Net.Sockets.TcpClient).Connect('127.0.0.1',%PORT%);break}catch{Start-Sleep -Milliseconds 250}}; Start-Process ('http://localhost:' + '%PORT%')"

%PYCMD% -m http.server %PORT% --bind %BIND%

echo.
echo Server stopped.
pause