import { readFileSync, writeFileSync, mkdirSync, rmSync } from "node:fs";
import { spawnSync } from "node:child_process";
import path from "node:path";
import { fileURLToPath } from "node:url";

import { HTML_PATH, extractScript } from "../tests/helpers.js";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const tmp = path.join(root, ".tmp-js-check");
try { mkdirSync(tmp, { recursive: true }); } catch (e) {}

const html = readFileSync(HTML_PATH, "utf8");
const js = extractScript(html);
const outPath = path.join(tmp, "app.js");
writeFileSync(outPath, js, "utf8");

const r = spawnSync(process.execPath, ["--check", outPath], { encoding: "utf8" });
try { rmSync(tmp, { recursive: true, force: true }); } catch (e) {}

if (r.error || r.status !== 0) {
  console.error("check:js FAILED — syntax error in the inline app script:\n" + (r.stderr || r.stdout));
  process.exit(1);
}
console.log("check:js OK — inline app script parses cleanly with node --check");