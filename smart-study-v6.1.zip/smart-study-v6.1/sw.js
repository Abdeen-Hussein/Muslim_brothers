const CACHE_NAME = "smart-study-v6-1-cache-2";
const APP_SHELL = [
  "./",
  "./index.html",
  "./manifest.json",
  "./icons/icon-192.png",
  "./icons/icon-512.png",
  "./icons/icon-512-maskable.png"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(APP_SHELL))
      .catch(()=>{})
      .then(()=> self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))))
      .then(()=> self.clients.claim())
  );
});

// Network-first for navigation/HTML, cache-first for local static assets,
// with deterministic offline fallback to the cached shell.
self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;

  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return; // cross-origin (fonts, api.aladhan.com) untouched

  const cachePromise = caches.open(CACHE_NAME);

  if (req.mode === "navigate") {
    event.respondWith(
      fetch(req)
        .then((res) => {
          if (res && res.status === 200) {
            cachePromise.then((cache) => cache.put(req, res.clone()));
          }
          return res;
        })
        .catch(() =>
          cachePromise
            .then((cache) => cache.match(req))
            .then((r) => r || cachePromise.then((c) => c.match("./index.html")))
            .catch(()=> Response.error())
        )
    );
    return;
  }

  // Local static assets: cache-first, with network fill-on-miss for icons/manifest only.
  event.respondWith(
    cachePromise
      .then((cache) => cache.match(req))
      .then((cached) => {
        if (cached) return cached;
        if (url.pathname.endsWith(".png") || url.pathname.endsWith(".json") || url.pathname.endsWith(".ico") || url.pathname.endsWith(".svg")) {
          return fetch(req).then((res) => {
            if (res && res.status === 200) {
              cachePromise.then((cache) => cache.put(req, res.clone()));
            }
            return res;
          }).catch(()=> Response.error());
        }
        return Response.error();
      })
      .catch(()=> Response.error())
  );
});