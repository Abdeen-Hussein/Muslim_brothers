import { openApp, closeApp, appErrors, gl } from "./tests/helpers.js";

const dom = openApp();
const w = dom.window;
const errs = appErrors(dom);
console.log("ERRORS:", JSON.stringify(errs));
console.log("state ok:", !!gl(w, "state"));
console.log("renderAll:", typeof w.renderAll);
console.log("decToHHMM(0.9999):", w.decToHHMM === undefined ? "n/a" : w.decToHHMM(0.9999));
console.log("APP const:", gl(w, "APP"));
console.log("pomoStatus id:", !!w.document.getElementById("pomoStatus"));
console.log("science tabs:", !!w.document.getElementById("sciencePageTabs"));
await closeApp(dom);
process.exit(errs.length ? 1 : 0);