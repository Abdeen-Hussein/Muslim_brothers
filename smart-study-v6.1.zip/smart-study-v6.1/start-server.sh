#!/usr/bin/env bash
# ============================================
#   الجدول الدراسي الذكي - الإصدار السادس
#   تشغيل خادم محلي (Linux / macOS / Termux على أندرويد)
#   الاستخدام: ./start-server.sh            (محلي فقط 127.0.0.1)
#              ./start-server.sh --lan      (متاح للشبكة المحلية 0.0.0.0)
# ============================================

cd "$(dirname "$0")" || exit 1

PORT=8000
BIND="127.0.0.1"
if [ "$1" = "--lan" ]; then
    BIND="0.0.0.0"
fi

echo "============================================"
echo "  الجدول الدراسي الذكي - خادم محلي"
echo "============================================"
echo ""

PYCMD=""
if command -v python3 >/dev/null 2>&1; then
    PYCMD="python3"
elif command -v python >/dev/null 2>&1; then
    PYCMD="python"
fi

if [ -z "$PYCMD" ]; then
    echo "[!] لم يتم العثور على بايثون."
    echo ""
    echo "على أندرويد عبر Termux، ثبّته بالأمر:"
    echo "    pkg install python -y"
    echo ""
    echo "على لينكس (Ubuntu/Debian):"
    echo "    sudo apt install python3 -y"
    echo ""
    echo "على macOS (عبر Homebrew):"
    echo "    brew install python3"
    echo ""
    exit 1
fi

echo "[OK] تم العثور على: $PYCMD"
echo ""

# Check if the port is already occupied (leftover process from a previous run)
port_busy() {
    if command -v curl >/dev/null 2>&1; then
        curl -s -o /dev/null --connect-timeout 1 "http://127.0.0.1:$1"
        return $?
    elif command -v nc >/dev/null 2>&1; then
        nc -z 127.0.0.1 "$1" >/dev/null 2>&1
        return $?
    else
        return 1
    fi
}
if port_busy "$PORT"; then
    echo "[!] المنفذ $PORT مستخدَم بالفعل (غالباً من تشغيل سابق لم يُغلق)."
    echo "    سنستخدم المنفذ 8001 بدلاً منه."
    PORT=8001
    echo ""
fi

# Only needed in --lan mode: detect the device's LAN IP so other devices
# on the same Wi-Fi (like your Android phone) can connect directly.
LAN_IP=""
if [ "$BIND" = "0.0.0.0" ]; then
    if command -v ip >/dev/null 2>&1; then
        LAN_IP=$(ip -4 addr show scope global 2>/dev/null | grep -oP '(?<=inet\s)\d+(\.\d+){3}' | head -n1)
    fi
    if [ -z "$LAN_IP" ] && command -v ifconfig >/dev/null 2>&1; then
        LAN_IP=$(ifconfig 2>/dev/null | grep -oE 'inet (addr:)?([0-9]{1,3}\.){3}[0-9]{1,3}' | grep -v '127.0.0.1' | awk '{print $2}' | sed 's/addr://' | head -n1)
    fi
    if [ -z "$LAN_IP" ] && command -v termux-wifi-connectioninfo >/dev/null 2>&1; then
        LAN_IP=$(termux-wifi-connectioninfo 2>/dev/null | grep -oE '"ip": *"[^"]+"' | grep -oE '([0-9]{1,3}\.){3}[0-9]{1,3}')
    fi
fi

echo "جارٍ تشغيل الخادم المحلي على المنفذ $PORT (الربط: $BIND) ..."
echo ""
echo "============================================"
echo "  على هذا الجهاز، افتح المتصفح على:"
echo "  http://localhost:$PORT"
echo ""
if [ -n "$LAN_IP" ]; then
echo "  الوضع --lan: من أي جهاز آخر على نفس شبكة الواي فاي"
echo "  (مثلاً جوالك أندرويد، بدون أي تطبيق إضافي):"
echo "  http://$LAN_IP:$PORT"
echo ""
fi
echo "  [!] إن ظهرت شاشة سوداء أو خطأ في الاتصال:"
echo "      انتظر لحظة ثم اضغط تحديث (Refresh) في المتصفح."
echo ""
echo "  لتثبيت التطبيق كأيقونة: من قائمة المتصفح ⋮ اختر"
echo "  'إضافة إلى الشاشة الرئيسية' أو 'تثبيت التطبيق'."
echo ""
echo "  للوصول من أجهزة أخرى على الشبكة: ./start-server.sh --lan"
echo ""
echo "  لإيقاف الخادم: اضغط Ctrl+C"
echo "============================================"
echo ""

# Wait for the server to actually start accepting connections before opening
# the browser (avoids a race condition that shows a blank/error page).
wait_and_open() {
    local tries=0
    while [ $tries -lt 40 ]; do
        if port_busy "$PORT"; then
            xdg-open "http://localhost:$PORT" 2>/dev/null \
                || open "http://localhost:$PORT" 2>/dev/null \
                || termux-open-url "http://localhost:$PORT" 2>/dev/null
            return 0
        fi
        sleep 0.25
        tries=$((tries+1))
    done
}
( wait_and_open ) &

exec "$PYCMD" -m http.server "$PORT" --bind "$BIND"