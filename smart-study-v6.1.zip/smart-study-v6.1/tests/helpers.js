import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { JSDOM, VirtualConsole } from "jsdom";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
export const HTML_PATH = path.join(ROOT, "index.html");
export const SW_PATH = path.join(ROOT, "sw.js");
export const MANIFEST_PATH = path.join(ROOT, "manifest.json");

const SCRIPT_RE = /<script>([\s\S]*?)<\/script>/;

const NOISE = /not implemented|css|stylesheet|serviceWorker|service worker/i;

export function loadHtml() {
  return readFileSync(HTML_PATH, "utf8");
}

export function extractScript(html) {
  const m = html.match(SCRIPT_RE);
  if (!m) throw new Error("no inline <script> block found");
  return m[1];
}

/** Filtered console errors — jsdom-only gaps (SW, CSS parsing, missing APIs) are not app defects. */
export function appErrors(dom) {
  return dom._errors.filter(msg => !NOISE.test(msg));
}

/** Open the full app in jsdom (runs the inline script), capturing console errors. */
export function openApp() {
  const html = loadHtml();
  const errors = [];
  const vc = new VirtualConsole();
  vc.on("error", (...a) => errors.push(a.map(String).join(" ")));
  vc.on("jsdomError", e => errors.push(String(e && (e.message || e))));
  const dom = new JSDOM(html, {
    runScripts: "dangerously",
    url: "http://localhost/",
    pretendToBeVisual: true
  });
  dom._errors = errors;
  return dom;
}

export async function closeApp(dom) {
  if (dom && dom.window) {
    try { dom.window.close(); } catch (e) {}
  }
}

/**
 * Global lexical bindings (`let state`, `const APP`, `let timer`, …) are not
 * `window` properties, so tests must read them through a realm eval.
 */
export function gl(w, name) {
  return w.eval(name);
}