﻿import { test, after } from "node:test";
import assert from "node:assert/strict";
import { openApp, closeApp, gl } from "./helpers.js";

let dom;
after(async () => { await closeApp(dom); dom = null; });

function app() {
  if (!dom) dom = openApp();
  return dom.window;
}
function state(w) { return gl(w, "state"); }
function dirty(w) { w.eval("_idxDirty = true"); }
function iso(d) { return d.toISOString(); }
function dayFor(d) { return d.toLocaleDateString("sv-SE"); }

test("decToHHMM / toDec / addMinutesHHMM are correct incl. 60-min rollover bug", () => {
  const w = app();
  assert.equal(w.decToHHMM(0), "00:00");
  assert.equal(w.decToHHMM(1.5), "01:30");
  assert.equal(w.decToHHMM(23.5), "23:30");
  assert.equal(w.decToHHMM(24), "00:00");
  assert.equal(w.decToHHMM(-0.5), "23:30");
  assert.ok(!w.decToHHMM(0.9999).includes("60"), "regression: 00:60 is impossible");
  assert.equal(w.decToHHMM(0.9999), "01:00");
  assert.equal(w.toDec("09:15"), 9.25);
  assert.equal(w.addMinutesHHMM("23:40", 30), "00:10");
  assert.equal(w.addMinutesHHMM("10:00", -30), "09:30");
  assert.equal(w.addMinutesHHMM("00:00", 1500), "01:00");
});

test("hm and fmtClock formatting helpers", () => {
  const w = app();
  assert.equal(w.hm(0), "0 د");
  assert.equal(w.hm(45), "45 د");
  assert.equal(w.hm(60), "1 س");
  assert.equal(w.hm(92), "1 س 32 د");
  assert.equal(w.fmtClock(0), "00:00:00");
  assert.equal(w.fmtClock(3661), "01:01:01");
  assert.equal(w.fmtClock(-5), "00:00:00");
});

test("dayKey returns sv-SE YYYY-MM-DD for a known date", () => {
  const w = app();
  const d = new Date(2026, 0, 5, 12, 0, 0); // 2026-01-05
  assert.equal(w.dayKey(d), "2026-01-05");
});

test("session index is honest vs brute-force (mixed subjects/days/modes)", () => {
  const w = app();
  const st = state(w);
  const n = 500;
  const list = [];
  const subjIds = ["math", "physics", "c_x1"];
  for (let i = 0; i < n; i++) {
    const daysAgo = i % 7;
    const d = new Date(); d.setDate(d.getDate() - daysAgo);
    list.push({ id: "t_" + i, date: dayFor(d), subject: subjIds[i % 3], seconds: 60 * (1 + (i % 40)), mode: (i % 5 === 0) ? "review" : "deep", material: "notebook", created: iso(new Date(Date.now() - i * 60000)) });
  }
  st.sessions = list;
  dirty(w);

  const bfSubjectSec = {}, bfCount = {}, allSec = {}, days = new Set(); let revCount = 0;
  for (const s of list) {
    allSec[s.date] = (allSec[s.date] || 0) + s.seconds;
    bfSubjectSec[s.subject] = (bfSubjectSec[s.subject] || 0) + s.seconds;
    bfCount[s.subject] = (bfCount[s.subject] || 0) + 1;
    if (s.mode === "review") revCount++;
    days.add(s.date);
  }
  for (const id of subjIds) {
    assert.equal(Math.round(w.minutesFor(id) * 100) / 100, Math.round(bfSubjectSec[id] / 60 * 100) / 100, `minutesFor ${id}`);
    assert.equal(w.sessionsCount(id), bfCount[id]);
  }
  assert.equal(w.secToday(), Math.round(allSec[w.dayKey()] || 0));
  assert.equal(w.reviewSessionsCount(), revCount);
  assert.equal(w.distinctDaysStudied(st), days.size);
  assert.equal(w.secAll(), list.reduce((a, s) => a + s.seconds, 0));
});

test("streak logic with freezes + gami data", () => {
  const w = app();
  const st = state(w);
  st.sessions = [];
  dirty(w);
  const today = new Date();
  const yKey = dayFor(new Date(today.getTime() - 86400000));
  const tKey = w.dayKey();
  assert.equal(w.streak(), 0);

  const mk = (dateKey, hOffset) => ({ id: "s_" + Math.random(), date: dateKey, subject: "math", seconds: 600, mode: "deep", material: "notebook", created: iso(new Date(today.getTime() - hOffset * 3600000)) });
  st.sessions.push(mk(yKey, 10));
  st.gami.freezesUsedAt = [tKey]; // today frozen, so streak carries over yesterday
  dirty(w);
  assert.equal(w.streak(), 1, "frozen today + studied yesterday = streak 1");
  st.sessions.push(mk(tKey, 2));
  dirty(w);
  assert.equal(w.streak(), 2);
});

test("save/load roundtrip through localStorage preserves state", () => {
  const w = app();
  const st = state(w);
  const before = st.sessions.length;
  st.settings.dailyTarget = 555;
  w.save();
  const raw = w.localStorage.getItem("smart-study-v6.1");
  assert.ok(raw);
  const restored = w.load();
  assert.equal(restored.settings.dailyTarget, 555);
  assert.equal(restored.version, 6);
  assert.notEqual(restored, st, "load returns a fresh object");
  assert.equal(st.sessions.length, before, "state untouched by load()");
  assert.equal(restored.sessions.length, before);
});

test("legacy smart-study-v4 backup is migrated, cleaned, and version pinned", () => {
  const w = app();
  w.localStorage.removeItem("smart-study-v6.1");
  const legacy = JSON.stringify({ subjects: { math: { name: "رياضيات", cat: "numerical", color: "#fff", target: 900, icon: "📐" } }, sessions: [] });
  w.localStorage.setItem("smart-study-v4", legacy);
  const st = w.load();
  assert.equal(st.version, 6);
  assert.equal(st.subjects.math.name, "رياضيات");
  assert.equal(w.localStorage.getItem("smart-study-v4"), null, "legacy key removed after migration");
  assert.ok(w.localStorage.getItem("smart-study-v6.1"), "migrated data persisted under new key");
});

test("goalProgress study_minutes_week counts only the current Sun..now window", () => {
  const w = app();
  const st = state(w);
  const g = { type: "study_minutes_week", target: 300 };
  const sunday = new Date(); sunday.setHours(0, 0, 0, 0); sunday.setDate(sunday.getDate() - sunday.getDay());
  const outside = new Date(sunday.getTime() - 86400000);
  st.sessions = [
    { id: "a", date: w.dayKey(new Date()), subject: "math", seconds: 120 * 60, mode: "deep", material: "notebook", created: iso(new Date()) },
    { id: "b", date: dayFor(outside), subject: "math", seconds: 9999, mode: "deep", material: "notebook", created: iso(outside) }
  ];
  dirty(w);
  const { cur } = w.goalProgress(g);
  assert.equal(cur, 120, "outside-week session must not count");
});

test("normalizeState clamps numeric settings and coerces arrays/objects", () => {
  const w = app();
  const dirty = { version: 6, sessions: "nope", notes: null, subjects: { math: { name: "x", target: 5 } }, settings: { dailyTarget: 5, pomoWork: 2, pomoBreak: 0 } };
  const clean = w.normalizeState(dirty);
  assert.ok(Array.isArray(clean.sessions));
  assert.ok(Array.isArray(clean.notes));
  assert.equal(clean.settings.dailyTarget, 30);
  assert.equal(clean.settings.pomoWork, 10);
  assert.equal(clean.settings.pomoBreak, 3);
  assert.equal(clean.subjects.math.target, 30);
});