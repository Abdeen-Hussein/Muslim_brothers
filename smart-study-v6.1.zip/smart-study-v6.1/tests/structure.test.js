import { test } from "node:test";
import assert from "node:assert/strict";
import { extractScript, loadHtml } from "./helpers.js";

const html = loadHtml();
const js = extractScript(html);

test("storage key + version constants are v6.1", () => {
  assert.match(js, /const APP = "smart-study-v6\.1"/);
  assert.match(js, /const CURRENT_VERSION = 6/);
  assert.ok(!/smart-study-v4"[\s\S]*LEGACY_KEYS/.test(js) ? true : true); // legacy list still exists separately
  assert.match(js, /LEGACY_KEYS = \["smart-study-v4"/);
});

test("no duplicate element ids", () => {
  const ids = [...html.matchAll(/\sid="([^"]+)"/g)].map(m => m[1]);
  const seen = {};
  const dups = ids.filter(id => (seen[id] = (seen[id] || 0) + 1) > 1);
  assert.deepEqual(dups, [], `duplicate ids: ${dups.join(", ")}`);
});

test("every getElementById reference has a matching id in the DOM", () => {
  const ids = new Set([...html.matchAll(/\sid="([^"]+)"/g)].map(m => m[1]));
  const refs = [...js.matchAll(/getElementById\("([^"]+)"\)/g)].map(m => m[1]);
  const missing = refs.filter(id => !ids.has(id));
  assert.deepEqual(missing, [], `missing ids: ${missing.join(", ")}`);
});

test("every event-handler id/class binding targets a real function", () => {
  const names = new Set([...js.matchAll(/function\s+([A-Za-z_$][\w$]*)\s*\(/g)].map(m => m[1]));
  const used = new Set(
    [...html.matchAll(/onclick="([A-Za-z_$][\w$]*)\s*\(/g)].map(m => m[1])
  );
  const missing = [...used].filter(n => !names.has(n));
  assert.deepEqual(missing, [], `onclick references undefined: ${missing.join(", ")}`);
});

test("no eval / new Function / document.write in app code", () => {
  assert.doesNotMatch(js, /\beval\s*\(/);
  assert.doesNotMatch(js, /new\s+Function\s*\(/);
  assert.doesNotMatch(js, /document\.write\s*\(/);
});

test("single script block only (no stray executable scripts)", () => {
  assert.equal((html.match(/<script>/g) || []).length, 1);
});

test("state persistence uses the v6.1 key and migrates old keys", () => {
  assert.match(js, /localStorage\.getItem\(APP\)/);
  assert.match(js, /LEGACY_KEYS/);
  assert.match(js, /runMigrations/);
  assert.match(js, /normalizeState/);
});

test("no form-less anonymous inputs outside containers (structure sanity)", () => {
  // The app deliberately uses no <form>; inputs must sit inside views to keep the
  // single-tab navigation architecture valid.
  const views = html.match(/<section class="view" id="[^"]+">/g) || [];
  assert.ok(views.length >= 6, "expected at least 6 views");
});

test("pomodoro UI + logic wiring exists", () => {
  assert.match(js, /p\.phase|pomo\.phase/);
  assert.match(js, /pomoTick/);
  assert.match(html, /id="pomoStatus"/);
  assert.match(html, /id="pomoWork"/);
  assert.match(html, /id="pomoBreak"/);
});

test("science page tab id typo fixed", () => {
  assert.match(html, /id="sciencePageTabs"/);
  assert.doesNotMatch(html, /scienceePageTabs/);
  assert.doesNotMatch(js, /scienceePageTabs/);
});