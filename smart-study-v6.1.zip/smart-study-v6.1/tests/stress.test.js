import { test, after } from "node:test";
import assert from "node:assert/strict";
import { openApp, closeApp, gl } from "./helpers.js";

let dom;
after(async () => { await closeApp(dom); dom = null; });

function app() {
  if (!dom) dom = openApp();
  return dom.window;
}
function iso(d) { return d.toISOString(); }
function dayFor(d) { return d.toLocaleDateString("sv-SE"); }

test("session index stays honest and fast at 20k sessions", () => {
  const w = app();
  const N = 20000;
  const list = [];
  const subjects = ["math", "physics", "biology", "c_quran"];
  for (let i = 0; i < N; i++) {
    const daysAgo = i % 60;
    const d = new Date(); d.setDate(d.getDate() - daysAgo);
    list.push({
      id: "s" + i,
      date: dayFor(d),
      subject: subjects[i % 4],
      seconds: 30 + (i % 5000),
      mode: (i % 20 === 0) ? "review" : "deep",
      material: "notebook",
      created: iso(new Date(Date.now() - i * 60000))
    });
  }
  gl(w,"state").sessions = list;
  w.eval("_idxDirty = true");

  const t0 = performance.now();
  w.ensureIndex();
  const buildMs = performance.now() - t0;
  assert.ok(buildMs < 3000, `index build took ${buildMs.toFixed(1)}ms`);

  const t1 = performance.now();
  let total = 0;
  for (let i = 0; i < 200; i++) total += w.secAll() + w.secWeek() + w.minutesFor(subjects[i % 4]) + w.distinctDaysStudied(gl(w,"state"));
  const queryMs = performance.now() - t1;
  assert.ok(queryMs < 3000, `200 mixed queries took ${queryMs.toFixed(1)}ms`);

  const bruteTotal = list.reduce((a, s) => a + s.seconds, 0);
  assert.equal(w.secAll(), bruteTotal);
  const bruteSubject = list.filter(s => s.subject === "c_quran").reduce((a, s) => a + s.seconds, 0);
  assert.equal(Math.round(w.minutesFor("c_quran") * 100) / 100, Math.round(bruteSubject / 60 * 100) / 100);
});

test("deepMerge handles 1000-deep nesting without errors", () => {
  const w = app();
  let deep = {};
  let cur = deep;
  for (let i = 0; i < 1000; i++) { cur.next = {}; cur = cur.next; }
  cur.leaf = true;
  const out = w.deepMerge(deep, { top: { added: 1 }, next: { next: {} } });
  // walk down and assert no crash and that leaf survived
  let node = out.deepest || out;
  assert.ok(node !== undefined);
  let walk = out, depth = 0;
  while (walk && walk.next && depth < 1005) { walk = walk.next; depth++; }
  assert.equal(depth, 1000);
  assert.equal(walk.leaf, true);
});

test("deepMerge split a large hostile-heavy object across many keys quickly and safely", () => {
  const w = app();
  const base = {};
  for (let i = 0; i < 5000; i++) base["k" + i] = { v: i, nested: { flag: i % 2 === 0 } };
  const t0 = performance.now();
  const out = w.deepMerge(base, { __proto__: { x: 1 }, extra: true });
  const ms = performance.now() - t0;
  assert.ok(ms < 2000, `merge took ${ms.toFixed(1)}ms`);
  assert.equal(({}).x, undefined);
  assert.equal(out.extra, true);
  assert.equal(out.k4999.v, 4999);
});

test("pomodoro loop over many cycles logs exactly one session per focus", () => {
  const w = app();
  gl(w,"state").settings.pomoWork = 10;
  gl(w,"state").settings.pomoBreak = 3;
  gl(w,"timer").subject = "math";
  gl(w,"timer").material = "notebook";
  gl(w,"timer").mode = "pomodoro";
  gl(w,"timer").running = false;
  const cycles = 50;
  const focusSec = 600, breakSec = 180, start = 100000;
  gl(w,"timer").pomo = { phase: "focus", cycleStart: start, n: 0, loggedSeconds: 0 };
  let e = start;
  const nbBefore = gl(w,"state").sessions.length;
  for (let i = 0; i < cycles; i++) {
    e += focusSec + 2;
    gl(w,"timer").elapsed = e;
    w.pomoTick();            // focus -> break (logs 1)
    assert.equal(gl(w,"timer").pomo.phase, "break");
    e += breakSec + 2;
    gl(w,"timer").elapsed = e;
    w.pomoTick();            // break -> focus (logs 0)
    assert.equal(gl(w,"timer").pomo.phase, "focus");
  }
  assert.equal(gl(w,"timer").pomo.n, cycles);
  assert.equal(gl(w,"state").sessions.length - nbBefore, cycles, "one session per completed focus");
  assert.equal(gl(w,"timer").pomo.loggedSeconds, cycles * (focusSec + 2), "logged total matches segments");
  gl(w,"timer").pomo = null;
});

test("escapeHtml throughput on worst-case input (10k iterations)", () => {
  const w = app();
  const dangerous = `a & b < c > d " e ' f`;
  const t0 = performance.now();
  for (let i = 0; i < 10000; i++) w.escapeHtml(dangerous);
  const ms = performance.now() - t0;
  assert.ok(ms < 2000, `escapeHtml x10k took ${ms.toFixed(1)}ms`);
  assert.equal(w.escapeHtml(dangerous), "a &amp; b &lt; c &gt; d &quot; e &#039; f");
});

test("normalizeState keeps large session arrays intact without reference sharing", () => {
  const w = app();
  const big = [];
  for (let i = 0; i < 20000; i++) big.push({ id: "id" + i, date: "2026-01-01", subject: "math", seconds: 60 });
  const t0 = performance.now();
  const st = w.normalizeState({ sessions: big, version: 6 });
  const ms = performance.now() - t0;
  assert.equal(st.sessions.length, 20000);
  assert.notEqual(st, big);
  assert.ok(ms < 2000, `normalize 20k took ${ms.toFixed(1)}ms`);
});