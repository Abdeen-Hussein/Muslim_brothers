import { test } from "node:test";
import assert from "node:assert/strict";
import { existsSync, readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { HTML_PATH, SW_PATH, MANIFEST_PATH, loadHtml } from "./helpers.js";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

test("PWA asset files exist", () => {
  for (const f of ["manifest.json", "sw.js", "icons/icon-192.png", "icons/icon-512.png", "icons/icon-512-maskable.png"]) {
    assert.ok(existsSync(path.join(ROOT, f)), `missing: ${f}`);
  }
});

test("manifest.json is valid and carries v6.1 metadata", () => {
  const m = JSON.parse(readFileSync(MANIFEST_PATH, "utf8"));
  assert.equal(m.name.includes("6.1"), true);
  assert.ok(m.id, "id field required for PWA install identity");
  assert.ok(Array.isArray(m.categories) && m.categories.length > 0);
  assert.ok(Array.isArray(m.shortcuts) && m.shortcuts.length >= 2);
  assert.ok(m.icons.some(i => i.sizes === "512x512" && i.purpose === "maskable"));
  assert.ok(m.start_url && m.scope);
});

test("sw.js is valid JS and implements the offline contract", () => {
  const text = readFileSync(SW_PATH, "utf8");
  assert.doesNotThrow(() => new Function(text));
  assert.match(text, /CACHE_NAME/);
  assert.match(text, /APP_SHELL/);
  assert.match(text, /self\.skipWaiting\(\)/);
  assert.match(text, /clients\.claim\(\)/);
  assert.match(text, /navigate/);
  assert.match(text, /index\.html/);
  assert.doesNotMatch(text, /importScripts/);
});

test("HTML loads the manifest and defines the app lang/dir", () => {
  const html = loadHtml();
  assert.match(html, /<html lang="ar" dir="rtl">/);
  assert.match(html, /rel="manifest" href="manifest\.json"/);
  assert.match(html, /Content-Security-Policy/);
});

test("service worker is registered from index.html", () => {
  const html = loadHtml();
  assert.match(html, /navigator\.serviceWorker\.register/);
});

test("external classic scripts are not required (single inline script)", () => {
  const html = loadHtml();
  const inline = (html.match(/<script>/g) || []).length;
  const external = (html.match(/<script[^>]+src=/g) || []).length;
  assert.equal(inline, 1);
  assert.equal(external, 0);
});

test("PWA icons referenced in manifest are valid PNG headers", () => {
  for (const name of ["icon-192.png", "icon-512.png", "icon-512-maskable.png"]) {
    const p = path.join(ROOT, "icons", name);
    const buf = readFileSync(p);
    assert.equal(buf[0], 0x89);
    assert.equal(buf[1], 0x50);
    assert.equal(buf[2], 0x4e);
    assert.equal(buf[3], 0x47);
    assert.ok(buf.length > 1000, `${name} suspiciously small`);
  }
});

test("server launchers default to localhost and support --lan", () => {
  const bat = readFileSync(path.join(ROOT, "start-server.bat"), "utf8");
  const sh = readFileSync(path.join(ROOT, "start-server.sh"), "utf8");
  assert.match(bat, /set BIND=127\.0\.0\.1/);
  assert.match(bat, /--lan/);
  assert.match(bat, /--bind %BIND%/);
  assert.match(sh, /BIND="127\.0\.0\.1"/);
  assert.match(sh, /--lan/);
  assert.match(sh, /--bind "\$BIND"/);
});