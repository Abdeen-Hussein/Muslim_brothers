import { test, after } from "node:test";
import assert from "node:assert/strict";
import { openApp, closeApp, appErrors, gl } from "./helpers.js";

let dom;
after(async () => { await closeApp(dom); dom = null; });

function app() {
  if (!dom) dom = openApp();
  return dom.window;
}

test("app boots (init render pipeline) without app-level console errors", () => {
  const w = app();
  assert.ok(gl(w,"state") && typeof gl(w,"state") === "object", "state global exists");
  assert.equal(typeof w.renderAll, "function");
  assert.equal(typeof w.setView, "function");
  assert.equal(typeof w.save, "function");
  const errs = appErrors(dom);
  assert.deepEqual(errs, [], `console errors during boot: ${errs.join(" | ")}`);
});

test("initial views are populated after full render", () => {
  const w = app();
  assert.ok(w.document.getElementById("homeSubjects").innerHTML.length > 0);
  assert.ok(w.document.getElementById("analyticsStats").querySelectorAll(".stat-card").length >= 4);
  assert.ok(w.document.getElementById("donutChart").innerHTML.includes("<circle"));
  assert.match(w.document.getElementById("heroClockDigits").textContent, /^\d{2}:\d{2}:\d{2}$/);
  assert.ok(w.document.getElementById("prayersMiniHome").innerHTML.length > 0);
});

test("submitSubject sanitises the name and adds a custom subject", () => {
  const w = app();
  const before = Object.keys(gl(w,"state").subjects).filter(k => k.startsWith("c_")).length;
  w.document.getElementById("newSubjName").value = "<b>الفيزياء</b><script>x</script>";
  w.document.getElementById("newSubjCat").value = "scientific";
  w.document.getElementById("newSubjTarget").value = 60;
  w.submitSubject();
  const added = Object.keys(gl(w,"state").subjects).filter(k => k.startsWith("c_"));
  assert.equal(added.length, before + 1);
  const sub = gl(w,"state").subjects[added[added.length - 1]];
  assert.ok(!sub.name.includes("<"), "name must be tag-free");
  assert.ok(!sub.name.includes("script"), "name must not contain script");
  assert.equal(sub.target, 3600, "target stored in seconds");
  const grid = w.document.getElementById("subjectCards");
  assert.ok(!grid.innerHTML.includes("<script"), "grid must not contain raw script");
});

test("timer render shows elapsed time and hides pomo status when inactive", () => {
  const w = app();
  gl(w,"timer").running = false;
  gl(w,"timer").elapsed = 125; // 00:02:05
  gl(w,"timer").pomo = null;
  w.renderTimer();
  assert.equal(w.document.getElementById("timerTime").textContent, "00:02:05");
  assert.equal(w.document.getElementById("pomoStatus").style.display, "none");
});

test("pomodoro cycle: focus completion logs a session and enters break", () => {
  const w = app();
  gl(w,"state").settings.pomoWork = 10;
  gl(w,"state").settings.pomoBreak = 3;
  gl(w,"timer").subject = "math";
  gl(w,"timer").material = "notebook";
  gl(w,"timer").mode = "pomodoro";
  gl(w,"timer").running = false;
  gl(w,"timer").elapsed = 0;
  const before = gl(w,"state").sessions.length;

  gl(w,"timer").pomo = { phase: "focus", cycleStart: 0, n: 0, loggedSeconds: 0 };
  gl(w,"timer").elapsed = 10 * 60 + 5;
  w.pomoTick();
  assert.equal(gl(w,"timer").pomo.phase, "break");
  assert.equal(gl(w,"timer").pomo.n, 1);
  const last = gl(w,"state").sessions[gl(w,"state").sessions.length - 1];
  assert.equal(last.mode, "pomodoro");
  assert.equal(last.seconds, 605);
  assert.equal(last.subject, "math");
  assert.equal(gl(w,"state").sessions.length, before + 1, "exactly one session logged");

  gl(w,"timer").elapsed = 10 * 60 + 3 * 60 + 5;
  const countBeforeBreak = gl(w,"state").sessions.length;
  w.pomoTick();
  assert.equal(gl(w,"timer").pomo.phase, "focus");
  assert.equal(gl(w,"state").sessions.length, countBeforeBreak, "break end must not log a session");
});

test("setView toggles views and the active nav states", () => {
  const w = app();
  w.setView("analytics");
  assert.equal(w.document.getElementById("analytics").classList.contains("active"), true);
  assert.equal(w.document.getElementById("home").classList.contains("active"), false);
  w.setView("home");
  assert.equal(w.document.getElementById("home").classList.contains("active"), true);
});

test("tasks open-count badge reflects number of open tasks", () => {
  const w = app();
  gl(w,"state").tasks = [
    { id: "t1", date: w.dayKey(), title: "مهمة أ", priority: 1, done: false },
    { id: "t2", date: w.dayKey(), title: "مهمة ب", priority: 2, done: true },
    { id: "t3", date: w.dayKey(), title: "مهمة ج", priority: 3, done: false }
  ];
  w.save();
  w.renderTasksView();
  assert.equal(w.document.getElementById("tasksOpenCountBadge").textContent, "2");
});

test("hero clock renders Hijri date line (element present and populated when ICU supports)", () => {
  const w = app();
  const el = w.document.getElementById("heroClockHijri");
  assert.ok(el, "heroClockHijri element must exist");
  w.renderHeroClock();
  assert.ok(!/\u0000/.test(el.textContent));
  if (el.textContent.trim() !== "") {
    assert.match(el.textContent, /هـ/);
    assert.match(el.textContent, /[\d\u0660-\u0669]/);
  }
});

test("science page tabs switch panes via the (typo-free) tab bar", () => {
  const w = app();
  assert.ok(w.document.getElementById("sciencePageTabs"));
  w.switchSciencePageTab("health");
  assert.equal(w.document.getElementById("sciencePane-health").classList.contains("active"), true);
  w.switchSciencePageTab("ruh");
  assert.equal(w.document.getElementById("sciencePane-ruh").classList.contains("active"), true);
});

test("storage event from another tab reloads state and re-renders", () => {
  const w = app();
  const before = gl(w,"state").tasks.length;
  const updated = JSON.parse(w.localStorage.getItem("smart-study-v6.1"));
  updated.tasks.push({ id: "tab2", date: w.dayKey(), title: "من تبويب آخر", priority: 1, done: false });
  w.localStorage.setItem("smart-study-v6.1", JSON.stringify(updated));

  const ev = new w.StorageEvent("storage", {
    key: "smart-study-v6.1",
    newValue: JSON.stringify(updated),
    oldValue: w.localStorage.getItem("smart-study-v6.1"),
    storageArea: w.localStorage,
    url: "http://localhost/"
  });
  assert.doesNotThrow(() => w.dispatchEvent(ev));
  assert.equal(gl(w,"state").tasks.length, before + 1, "state must reload from storage event");
  const titles = gl(w,"state").tasks.map(t => t.title);
  assert.ok(titles.includes("من تبويب آخر"));
});

test("storage event from an unrelated key is ignored", () => {
  const w = app();
  const before = gl(w,"state").tasks.length;
  const ev = new w.StorageEvent("storage", { key: "some_other_app", newValue: "x", url: "http://localhost/" });
  w.dispatchEvent(ev);
  assert.equal(gl(w,"state").tasks.length, before);
});

test("active session is protected from cross-tab clobbering", () => {
  const w = app();
  gl(w,"timer").running = true;
  const before = gl(w,"state").tasks.length;
  const ev = new w.StorageEvent("storage", { key: "smart-study-v6.1", newValue: "{}", url: "http://localhost/" });
  w.dispatchEvent(ev);
  assert.equal(gl(w,"state").tasks.length, before, "state must not reload while timer is running");
  gl(w,"timer").running = false;
});