import { test, after } from "node:test";
import assert from "node:assert/strict";
import { openApp, closeApp, gl } from "./helpers.js";

let dom;
after(async () => { await closeApp(dom); dom = null; });

function app() {
  if (!dom) dom = openApp();
  return dom.window;
}

const XSS_NAME = `<script>window.__pwned=1</script><img src=x onerror="window.__pwned=2">`; 

test("deepMerge blocks prototype pollution via __proto__/constructor", () => {
  const w = app();
  const evil = JSON.parse('{"a":{"b":1},"__proto__":{"polluted":true},"constructor":{"prototype":{"polluted2":true}}}');
  const out = w.deepMerge(w.defaultState(), evil);
  assert.equal(Object.prototype.polluted, undefined);
  assert.equal(Object.prototype.polluted2, undefined);
  assert.equal(("polluted" in out) ? out.polluted : undefined, undefined);
  const keys = Object.keys(out);
  assert.ok(!keys.includes("__proto__"));
  assert.ok(!keys.includes("constructor"));
  const fresh = {};
  assert.equal(fresh.polluted, undefined);
});

test("deepMerge produces fresh objects (no shared references into input)", () => {
  const w = app();
  const a = { deep: { list: [1, 2] }, arr: [3] };
  const b = { deep: { extra: true } };
  const out = w.deepMerge(a, b);
  assert.deepEqual(JSON.parse(JSON.stringify(out.deep)), { list: [1, 2], extra: true });
  out.deep.list.push(99);
  assert.deepEqual(a.deep.list, [1, 2], "mutating merged copy leaked into source");
  assert.notEqual(out, a);
});

test("deepMerge array branch is replaced wholesale by new array object", () => {
  const w = app();
  const a = { sessions: [{ x: 1 }] };
  const b = { sessions: [{ y: 2 }] };
  const out = w.deepMerge(a, b);
  assert.deepEqual(JSON.parse(JSON.stringify(out.sessions)), [{ y: 2 }]);
  out.sessions.push({ z: 3 });
  assert.equal(a.sessions.length, 1);
});

test("deepMerge with nested hostile key deep in tree is ignored", () => {
  const w = app();
  const evil = { plain: 1, nested: JSON.parse('{"__proto__":{"polluted3":true},"ok":"fine"}') };
  const out = w.deepMerge({}, evil);
  assert.equal(({}).polluted3, undefined);
  assert.equal(out.nested.ok, "fine");
  assert.ok(!Object.keys(out.nested).includes("__proto__"));
});

test("escapeHtml encodes the five dangerous characters", () => {
  const w = app();
  assert.equal(w.escapeHtml(`<a href="x" onclick='y'>&`), "&lt;a href=&quot;x&quot; onclick=&#039;y&#039;&gt;&amp;");
});

test("sanitizeName strips tags/control chars and clamps length", () => {
  const w = app();
  assert.equal(w.sanitizeName(XSS_NAME), "window.__pwned=1");
  assert.equal(w.sanitizeName("  سلام  "), "سلام");
  assert.equal(w.sanitizeName("a".repeat(200)).length, 80);
  assert.equal(w.sanitizeName("<"), "مادة");
  assert.equal(w.sanitizeName("\u0000abc\u0007"), "abc");
});

test("XSS subject name is escaped in subjects grid, session log, home and donut", () => {
  const w = app();
  const id = "c_xsstest";
  gl(w,"state").subjects[id] = { name: XSS_NAME, cat: "language", color: "#ffffff", target: 900, icon: "🧪" };
  w.renderSubjectsGrid();
  assert.match(w.document.getElementById("subjectCards").innerHTML, /&lt;script&gt;/);
  assert.doesNotMatch(w.document.getElementById("subjectCards").innerHTML, /<script>/);
  assert.ok(!w.document.getElementById("subjectCards").innerHTML.includes("<img"), "no live img tag carrying onerror");

  const today = w.dayKey();
  gl(w,"state").sessions.push({ id: "s_x", date: today, subject: id, seconds: 600, mode: "deep", material: "notebook", created: new Date().toISOString() });
  w.eval("_idxDirty = true");
  w.renderSessionLog();
  const log = w.document.getElementById("sessionLog").innerHTML;
  assert.ok(log.includes("&lt;script&gt;"));
  assert.ok(!log.includes("<script>"));

  w.renderHome();
  const home = w.document.getElementById("homeSubjects").innerHTML;
  assert.ok(home.includes("&lt;script&gt;"));
  assert.ok(!home.includes("<script>"));

  w.renderDonut();
  assert.ok(w.document.getElementById("donutLegend").innerHTML.includes("&lt;script&gt;"));

  w.renderAnalyticsStats();
  w.renderAnalyticsQuizzes();
  const quizList = w.document.getElementById("analyticsQuizzes").innerHTML;
  assert.ok(!quizList.includes("onerror="));

  // clean up
  delete gl(w,"state").subjects[id];
  gl(w,"state").sessions = gl(w,"state").sessions.filter(s => s.subject !== id);
  w.eval("_idxDirty = true");
});

test("import pipeline neutralises hostile payloads end-to-end", () => {
  const w = app();
  const payload = {
    version: 999,
    subjects: { "c_bad": { name: XSS_NAME, __proto__: { dirty: true } }, "c_bad2": "not-an-object" },
    sessions: "string-that-is-not-an-array",
    settings: { dailyTarget: 1, pomoWork: 1, pomoBreak: 1 },
    __proto__: { polluted4: 1 }
  };
  const st = w.runMigrations(w.normalizeState(w.deepMerge(w.defaultState(), payload)));
  assert.equal(({}).polluted4, undefined);
  assert.equal(({}).dirty, undefined, "nested __proto__ inside a subject must not pollute");
  assert.ok(Array.isArray(st.sessions), "sessions must be coerced to array");
  assert.equal(st.settings.dailyTarget, 30, "dailyTarget clamped to floor 30");
  assert.equal(st.settings.pomoWork, 10, "pomoWork clamped to floor 10");
  assert.ok(!st.subjects["c_bad2"], "non-object subject must be dropped");
  const kept = st.subjects["c_bad"];
  assert.ok(kept && typeof kept === "object", "object subject survives as plain object");
  assert.equal(typeof kept.name, "string");
  assert.ok(!kept.name.includes("<"), "subject name sanitized of tags");
  assert.ok(!kept.name.includes("script"), "subject name sanitized of scripts");
  assert.ok(!Object.keys(kept).includes("__proto__"), "no __proto__ key leaks into stored subject");
  const keys = Object.keys(st.subjects);
  assert.ok(!keys.includes("__proto__") && !keys.includes("constructor"));
});

test("safeOpenUrl only allows http/https and never javascript:/data:", () => {
  const w = app();
  const calls = [];
  w.open = (url, name, features) => { calls.push([url, name, features]); return null; };
  w.safeOpenUrl("javascript:alert(1)");
  w.safeOpenUrl("data:text/html,evil");
  w.safeOpenUrl("file:///etc/passwd");
  assert.equal(calls.length, 0);
  w.safeOpenUrl("https://example.com/x");
  assert.equal(calls.length, 1);
  assert.equal(calls[0][2], "noopener,noreferrer");
  // allow a protocol-relative-ish transparent http URL too
  w.safeOpenUrl("http://example.com");
  assert.equal(calls.length, 2);
  w.open = undefined;
});

test("no object URL leaks: viewer URL is revoked on close", () => {
  const w = app();
  let revoked = 0;
  const orig = w.URL.revokeObjectURL;
  w.URL.revokeObjectURL = () => { revoked++; };
  // simulate a loaded viewer frame
  w.openMaterialViewer = undefined; // not needed; test closeViewer path directly
  const body = w.document.getElementById("viewerBody");
  body.dataset.url = "blob:fake";
  w.closeViewer();
  assert.ok(revoked >= 1, "viewer URL should be revoked on close");
  assert.equal(body.dataset.url, undefined);
  w.URL.revokeObjectURL = orig;
});